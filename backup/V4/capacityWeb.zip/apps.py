from django.apps import AppConfig


class CapacitywebConfig(AppConfig):
    name = 'capacityWeb'


